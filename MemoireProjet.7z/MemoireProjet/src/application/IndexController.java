package application;

import java.net.MalformedURLException;
import java.net.URISyntaxException;

import javafx.animation.Animation;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import javafx.util.Duration;

// ce controller va se charger de la gestion des actions des utilisateurs : il est en lien avec le modele et la vue

public class IndexController {
	
	@FXML
	private Button bouttonCommencer;
	@FXML
	private Label panneauTitre;
	@FXML
	private Label labelScore;
	@FXML
	private GridPane gridCartes;
	@FXML
	private GridPane gridCartesFace;
	@FXML
	private Label labelTimer;
	@FXML
	private Pane mainPane;
	
	private int tempsRestant = 180;
	private int score = 0;
	private boolean timesUp = false;
	
	@FXML
	private Button button0;
	@FXML
	private Button button1;
	@FXML
	private Button button2;
	@FXML
	private Button button3;
	@FXML
	private Button button4;
	@FXML
	private Button button5;
	
	@FXML
	private ImageView testImg;

	@FXML
	private void buttonCarteClique(ActionEvent evt) {
		if(evt.getSource() instanceof Button) {
			Button bt = (Button) evt.getSource();
			bt.setVisible(false);
		}
	}
	
	@FXML
	private void commencerJeu(ActionEvent evt) {
		// on cache les labels
		this.bouttonCommencer.setVisible(false);
		this.panneauTitre.setVisible(false);
		
		
		// on affiche un message d'information
		Alert boiteAlerte = new Alert(AlertType.INFORMATION);
		boiteAlerte.setTitle("Allons-y !");
		boiteAlerte.setHeaderText("Jeu2Cartes");
		boiteAlerte.setContentText("Vous devez trouver toutes les paires de cartes dans le temps imparti.");
		boiteAlerte.showAndWait();
		
		// on affiche le "tableau" de jeu
		this.gridCartes.setVisible(true);
		this.gridCartesFace.setVisible(true);
		this.labelScore.setVisible(true);
		
		// on initialise le score et le temps
		afficherScore();
		
		Timeline timer = new Timeline(new KeyFrame(Duration.millis(1000), ae -> afficherTimer()));
		timer.setCycleCount(Animation.INDEFINITE);
		timer.play();
		if (this.tempsRestant == 0) {
            timer.stop();
            this.timesUp = true;
        }
		
		// on ajoute les cartes sur le tableau
		Paquet paquet = new Paquet(); // on cree le paquet
		int k = 0;
		for(Carte carte : paquet.getPaquet()) {
			Image image = new Image(carte.getUrlImage());
			ImageView imageView = new ImageView(image);
			imageView.setFitHeight(200);
			imageView.setFitWidth(150);
			int i = k % this.gridCartesFace.getColumnCount();
			int j = k / this.gridCartesFace.getColumnCount();
			this.gridCartesFace.add(imageView, i, j);
			k++;
		}
		
		
		jouer();
	}
	
	private void afficherTimer() {
		this.tempsRestant--;
		this.labelTimer.setVisible(true);
		this.labelTimer.setText("Temps restant : " + this.tempsRestant + " secondes.");
	}
	
	private void afficherScore() {
		this.labelScore.setText("Score : " + this.score);
	}
	
	private void jouer() {
		// boucle du jeu
		
		// FAIRE LA BOUCLE DE JEU : WHILE(Temps n'est pas atteint et qu'il y a des cartes encore..)
		
		//while(!this.timesUp && !this.plusDeCartes) {
			// jouer
		//}
	}
}
