# Organisation
- J'ai commence par penser le jeu avec des classes et le modele MVC, cela m'a pris une seance entiere (pas de code, simplement penser aux classes et au fonctionnement du jeu en general.)
	J'ai tout note sur papier (classes, relations, MVC, logique du jeu...)
- Pour la deuxieme seance j'ai commence a coder le model : Classe carte et paquet (j'ai du coder 1 ou 2 h a la maison aussi)
	 j'avais fini de coder la partie model (les classes de base gerant le fonctionnement des paquets et des cartes) et j'ai commence a faire la partie Vue : Travail avec SceneBuilder etc
- Pour la derniere seance j'ai code  surtout la partie controller, afin de gerer les acitions de l'utilisateur avec les boutons, le chargement et affichage du paquet de cartes...

Je n'ai pas pu fini le jeu :
	- Il me reste a implementer la logique du jeu (boucle de jeu) : quand le joeur clique sur deux cartes, qu'on les compare et on les cache, qu'on augmente le score s'il a trouve...
	- J'ai passe pas mal de temps sur l'interface, a galerer pour mettre les elements la ou il fallait et a charger le visuel des cartes. (Pas mal de problemes avec les images)
	- Il m'a manque une seance pour finir et faire en sorte que ce soit jouabl
	- Au debut je voulais faire plus de choses mais avec le temps je me suis rendu compte qu'il fallait faire encore plus simple -> rendre un jeu qui fonctionne

# Contraintes

-> Temps assez limite
-> Je viens de decouvrir JavaFX, donc j'ai fait comme j'ai pu

# Choses a ameliorer

-> Peut etre commencer avant a coder, j'ai peut-etre passe trop de temps sur la logique du jeu
-> J'aurais du faire encore plus simple et aller plus vite a l'essentiel -> faire en sorte que le jeu marche

# Helpers
Kylan Slamian
Antoine Graire
Philippe Roussille :)